// const mongoose = require("mongoose");
// const request = require("supertest-as-promised");
// const httpStatus = require("http-status");
// const chai = require("chai"); // eslint-disable-line import/newline-after-import
// const expect = chai.expect;
// const app = require("../../index");

// chai.config.includeStack = true;

// /**
//  * root level hooks
//  */
// let token = "";
// before(done => {
//   // required because https://github.com/Automattic/mongoose/issues/1251#issuecomment-65793092
//   let credentials = {
//     email: "jest@gmail.com",
//     password: "jest1234"
//   };

//   request(app)
//     .post("/api/v1/account/login")
//     .send(credentials)
//     .expect(200)
//     .then(res => {
//       //expect(res.body.success).to.equal(true);
//       token = res.body.token;
//       done();
//     })
    
//     .catch(done);
// });
// after(done => {
//   // required because https://github.com/Automattic/mongoose/issues/1251#issuecomment-65793092
//   mongoose.models = {};
//   mongoose.modelSchemas = {};
//   mongoose.connection.close();
//   done();
// });

// describe("## comment APIs", () => {
//   let comment = {
//     text: "ck",
//     postRef: "5cdb989faf732f49f137b820"
//   };

//   describe("# SAVE /api/comments", () => {
//     it("should not create a new save of comment without login", done => {
//       request(app)
//         .post("/api/v1/comments")
//         .send(comment)
//         .expect(httpStatus.UNAUTHORIZED)
//         .end((err, res) => {
//           done(err);
//         });
//     });

//     it("should create a new save of comment", done => {
//       request(app)
//         .post("/api/v1/comments")
//         .set("Authorization", token)
//         .send(comment)
//         .expect(httpStatus.OK)
//         .then(res => {
//           expect(res.body.postRef).to.equal(comment.postRef);
//           expect(res.body.text).to.equal(comment.text);
//           comment = res.body;
//           done();
//         })
        
//         .catch(done);
//     });
//   });

//   describe("# GET /api/comments/:commentId", () => {
//     it("should nto get comment details witout login", done => {
//       request(app)
//         .get(`/api/v1/comments/${comment._id}`)

//         .expect(httpStatus.UNAUTHORIZED)
//         .end((err) => {
//           done(err);
//         });
//     });
//     it("should get coemment details", done => {
//       request(app)
//         .get(`/api/v1/comments/${comment._id}`)
//         .set("Authorization", token)
//         .expect(httpStatus.OK)
//         .then(res => {
//           expect(res.body.postRef).to.equal(comment.postRef);
//           expect(res.body.text).to.equal(comment.text);
//           done();
//         })
//         .catch(done);
//     });
//   });

//   describe("# GET /api/comments/", () => {
//     //may be change to connection by post
//     it("should get all saves comments item", done => {
//       request(app)
//         .get("/api/v1/comments")
//         .set("Authorization", token)
//         .expect(httpStatus.OK)
//         .then(res => {
//           expect(res.body).to.be.an("array");
//           done();
//         })
//         .catch(done);
//     });

//     it("should get all comments (with limit and skip)", done => {
//       request(app)
//         .get("/api/v1/comments")
//         .set("Authorization", token)
//         .query({ limit: 10, skip: 1 })
//         .expect(httpStatus.OK)
//         .then(res => {
//           expect(res.body).to.be.an("array");
//           done();
//         })
//         .catch(done);
//     });
//   });

//   describe("# Like /api/comments/", () => {
//     it("should not like comment without login", done => {
//       request(app)
//         .get(`/api/v1/comments/likes/${comment._id}`)

//         .expect(httpStatus.UNAUTHORIZED)
//         .end((err) => {
//           done(err);
//         });
//     });
//     it("should like comment", done => {
//       request(app)
//         .get(`/api/v1/comments/likes/${comment._id}`)
//         .set("Authorization", token)
//         .expect(httpStatus.OK)
//         .then(res => {
//           expect(res.body.like)
//             .to.be.an("array")
//             .that.includes("5cdb98cdab24ca4b10407752");

//           done();
//         })
//         .catch(done);
//     });
//   });

//   describe("# Respects /api/comments/", () => {
//     it("should not respect comment without lgoin", done => {
//       request(app)
//         .get(`/api/v1/comments/respectes/${comment._id}`)

//         .expect(httpStatus.UNAUTHORIZED)
//         .end((err) => {
//           done(err);
//         });
//     });
//     it("should respect post", done => {
//       request(app)
//         .get(`/api/v1/comments/respectes/${comment._id}`)
//         .set("Authorization", token)
//         .expect(httpStatus.OK)
//         .then(res => {
//           expect(res.body.like)
//             .to.be.an("array")
//             .that.includes("5cdb98cdab24ca4b10407752");
//           done();
//         })
//         .catch(done);
//     });
//   });

//   describe("# DELETE /api/comments/", () => {
//     it("should not delete comment with auth and self premmission", done => {
//       request(app)
//         .delete(`/api/v1/comments/${comment._id}`)

//         .expect(httpStatus.UNAUTHORIZED)
//         .end((err) => {
//           done(err);
//         });
//     });
//     it("should delete comment with auth and self premmission", done => {
//       request(app)
//         .delete(`/api/v1/comments/${comment._id}`)
//         .set("Authorization", token)
//         .expect(httpStatus.OK)
//         .then(res => {
//           expect(res.body.removed).to.equal(true);
//           done();
//         })
//         .catch(done);
//     });
//   });
// });
